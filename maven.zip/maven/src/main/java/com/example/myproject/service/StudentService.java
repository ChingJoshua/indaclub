package com.example.myproject.service;

import com.example.myproject.entity.Student;
import com.example.myproject.entity.StudyGroup;
import com.example.myproject.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;
import java.util.Optional;

@Service
public class StudentService {

	@Autowired
	private StudentRepository studentRepository;

	public Optional<Student> getStudentWithStudyGroups(Long studentId) {
		return studentRepository.findById(studentId);
	}

	public List<Student> getAllStudents() {
		return ((ListCrudRepository<Student, Long>) studentRepository).findAll();

	}

	public Student saveStudent(Student student) {
		return studentRepository.save(student);
	}

	public Student findStudentById(Long studentId) {
		return studentRepository.findById(studentId).orElse(null);
	}

	public Optional<Student> findByEmailAndPassword(String email, String password) {
		 return studentRepository.findByEmailAndPassword(email, password);
	}

	
}