package com.example.myproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.myproject.entity.StudyGroup;

public interface StudyGroupRepository extends JpaRepository<StudyGroup, Long> {


}