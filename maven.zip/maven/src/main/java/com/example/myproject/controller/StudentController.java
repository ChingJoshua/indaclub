package com.example.myproject.controller;

import com.example.myproject.entity.Student;
import com.example.myproject.service.StudentService;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional; 

@Controller // Use @Controller instead of @RestController
public class StudentController {

    @Autowired
    private StudentService studentService;

    @GetMapping("/students/{studentId}")
    public String getStudentWithStudyGroups(@PathVariable Long studentId, Model model) {
        Optional<Student> studentOpt = studentService.getStudentWithStudyGroups(studentId);
        if (studentOpt.isPresent()) {
            model.addAttribute("student", studentOpt.get());
            return "student"; // This is correctly interpreted as a view name
        } else {
            return "student-not-found"; // Ensure you have a template for this case
        }
        
    }
    @Autowired
    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @GetMapping("/students/new")
    public String showCreateStudentForm(Model model) {
        model.addAttribute("student", new Student());
        return "create-student";
    }
    
    
    @PostMapping("/students")
    public String createStudent(Student student) {
        studentService.saveStudent(student);
        return "redirect:/students/new"; // Adjust the redirect as needed
    }
    
    @GetMapping("/signup")
    public String showSignUp(Model model) {
        model.addAttribute("student", new Student());
        return "signup";
    }
    @PostMapping("/signup")
	public String signUp(@ModelAttribute Student student) {
    	studentService.saveStudent(student);
		return "redirect:/signin";
	}
    
    @PostMapping("/signin")
    public String signIn(@RequestParam String email, @RequestParam String password, HttpSession session, RedirectAttributes redirectAttributes) {
        Optional<Student> studentOpt = studentService.findByEmailAndPassword(email, password); // Implement this method in your service
        if (studentOpt.isPresent()) {
            session.setAttribute("userId", studentOpt.get().getId()); // Store user ID in session
            return "redirect:/studygroups/all";
        } else {
            redirectAttributes.addFlashAttribute("error", "Invalid credentials");
            return "redirect:/signin";
        }
    }
    
//    @GetMapping("/somePage")
//    public String somePage(HttpSession session, Model model) {
//        Long userId = (Long) session.getAttribute("userId");
//        if (userId == null) {
//            // Handle case where there is no user in session, e.g., redirect to sign-in page
//            return "redirect:/signin";
//        }
//        // Use the userId as needed
//        return "somePage";
//    }
}
