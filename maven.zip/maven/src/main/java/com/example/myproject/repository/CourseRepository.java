package com.example.myproject.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.myproject.entity.Course;
import com.example.myproject.entity.StudyGroup;

public interface CourseRepository extends JpaRepository<Course, Long> {
}
