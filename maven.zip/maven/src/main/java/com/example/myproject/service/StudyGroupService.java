package com.example.myproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.ListCrudRepository;
import org.springframework.stereotype.Service;

import com.example.myproject.entity.Student;
import com.example.myproject.entity.StudyGroup;
import com.example.myproject.repository.StudyGroupRepository;

import java.util.List;
import java.util.Optional;

@Service
public class StudyGroupService {

    private final StudyGroupRepository studyGroupRepository;

    @Autowired
    public StudyGroupService(StudyGroupRepository studyGroupRepository) {
        this.studyGroupRepository = studyGroupRepository;
    }

    public List<StudyGroup> getAllStudyGroups() {
        return ((ListCrudRepository<StudyGroup, Long>) studyGroupRepository).findAll();
    }
 // Method to save a study group
    public StudyGroup saveStudyGroup(StudyGroup studyGroup) {
        // Save the study group to the database
        return studyGroupRepository.save(studyGroup);
    }

    public void addStudentToStudyGroup(Long studyGroupId, Student student) {
        StudyGroup studyGroup = studyGroupRepository.findById(studyGroupId)
                .orElseThrow(() -> new RuntimeException("StudyGroup not found with id " + studyGroupId));
        studyGroup.getMembers().add(student);
        studyGroupRepository.save(studyGroup);
    }
    
    public Optional<StudyGroup> findStudyGroupById(Long id) {
        return studyGroupRepository.findById(id);
    }
    public void deleteStudyGroupById(Long id) {
        studyGroupRepository.deleteById(id);
    }
    


}