package com.example.myproject.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.myproject.entity.Course;
import com.example.myproject.repository.CourseRepository;
import com.example.myproject.repository.StudentRepository;
@Service
public class CourseService {
	
	@Autowired
	private CourseRepository courseRepository;
	public Course findCourseById(Long id) {
	    return courseRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Course not found"));
	}
}
