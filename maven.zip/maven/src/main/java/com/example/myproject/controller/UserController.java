package com.example.myproject.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.example.myproject.entity.Student;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {

    @GetMapping("/signin")
    public String showSignInForm() {
        // Simply returns the sign-in view.
        return "signin";
    }




    @PostMapping("/signout")
    public String signOut(HttpSession session) {
        session.invalidate(); // Invalidate session to clear any stored user information
        return "redirect:/home"; // Redirect user to sign-in page
    }
   

    @GetMapping("/home")
    public String home() {
        // Returns the home page view.
        return "home";
    }
}

