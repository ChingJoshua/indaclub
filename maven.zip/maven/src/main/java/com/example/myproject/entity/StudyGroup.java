package com.example.myproject.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;

@Entity
@Table(name = "studygroup")
public class StudyGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "SG_ID")
    private Long id;

    @Column(name = "SG_NAME", nullable = false, length = 50)
    private String name;

    @Column(name = "SG_WEEKDAY", nullable = false, length = 50)
    private String weekDay;

    @Column(name = "SG_TIME", nullable = false)
    private String time;

    @Column(name = "SG_LOCATION", nullable = false, length = 50)
    private String location;

    @ManyToOne
    @JoinColumn(name = "OWNER_ID", nullable = false)
    private Student owner;

    @ManyToOne
    @JoinColumn(name = "COURSE_ID", nullable = false)
    private Course course;
    
 // New field for the many-to-many relationship
    @ManyToMany
    @JoinTable(
        name = "studentstudygroup",
        joinColumns = @JoinColumn(name = "SG_ID"),
        inverseJoinColumns = @JoinColumn(name = "STUDENT_ID")
    )
    private Set<Student> members;

    // Getters and Setters
    public Set<Student> getMembers() {
        return members;
    }

    public void setMembers(Set<Student> members) {
        this.members = members;
    }
    
    
    
    
    
    // Constructors, Getters, and Setters
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getWeekDay() {
		return weekDay;
	}

	public void setWeekDay(String weekDay) {
		this.weekDay = weekDay;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Student getOwner() {
		return owner;
	}

	public void setOwner(Student owner) {
		this.owner = owner;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

    
    
    
}