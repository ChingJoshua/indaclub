package com.example.myproject.repository;


import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.myproject.entity.Student;
import com.example.myproject.entity.StudyGroup;

public interface StudentRepository extends JpaRepository<Student, Long> {

	Optional<Student> findByEmailAndPassword(String email, String password);
}
