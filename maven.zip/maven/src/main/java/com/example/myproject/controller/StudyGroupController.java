package com.example.myproject.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.myproject.entity.Course;
import com.example.myproject.entity.Student;
import com.example.myproject.entity.StudyGroup;
import com.example.myproject.service.CourseService;
import com.example.myproject.service.StudentService;
import com.example.myproject.service.StudyGroupService;

import jakarta.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.example.myproject.entity.StudyGroup;
import com.example.myproject.service.StudyGroupService;
import java.util.Optional;
@Controller
@RequestMapping("/studygroups")
public class StudyGroupController {

    private final StudyGroupService studyGroupService;
    private final StudentService studentService;
    private final CourseService courseService; // Add CourseService

    @Autowired
    public StudyGroupController(StudyGroupService studyGroupService, StudentService studentService, CourseService courseService) {
        this.studyGroupService = studyGroupService;
        this.studentService = studentService;
        this.courseService = courseService; // Initialize CourseService
    }

    @GetMapping("/new")
    public String showCreateStudyGroupForm(Model model) {
        model.addAttribute("studyGroup", new StudyGroup());
        return "create-studygroup";
    }

    @PostMapping
    public String createStudyGroup(@ModelAttribute StudyGroup studyGroup, HttpSession session, RedirectAttributes redirectAttributes) {
        Long studentId = (Long) session.getAttribute("userId");
        if (studentId == null) {
            redirectAttributes.addFlashAttribute("error", "You must be signed in to create a study group.");
            return "redirect:/signin";
        }

        Student student = studentService.findStudentById(studentId);
        Course course = courseService.findCourseById(101L); // Assume course with ID 101 exists

        studyGroup.setOwner(student);
        studyGroup.setCourse(course);

        studyGroupService.saveStudyGroup(studyGroup);
        redirectAttributes.addFlashAttribute("success", "Study group created successfully.");
        return "redirect:/studygroups/all";
    }

    @GetMapping("/all")
    public String listStudyGroups(Model model) {
        List<StudyGroup> studyGroups = studyGroupService.getAllStudyGroups();
        model.addAttribute("studyGroups", studyGroups);
        return "studygroups";
    }

    @PostMapping("/join")
    public String joinStudyGroup(@RequestParam("studyGroupId") Long studyGroupId, HttpSession session, RedirectAttributes redirectAttributes) {
        Long studentId = (Long) session.getAttribute("userId");
        // The join logic remains the same
        // ...
        return "redirect:/studygroups/all";
    }
    
    @GetMapping("view/{id}")
    public String viewStudyGroup(@PathVariable Long id, Model model) {
        Optional<StudyGroup> studyGroupOpt = studyGroupService.findStudyGroupById(id);
        if (!studyGroupOpt.isPresent()) {
            return "study-group-not-found"; // Return a view indicating the study group was not found
        }
        model.addAttribute("studyGroup", studyGroupOpt.get());
        return "view-study-group"; // Name of the Thymeleaf template
    }
    @PostMapping("delete/{id}")
    public String deleteStudyGroup(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        Optional<StudyGroup> studyGroupOpt = studyGroupService.findStudyGroupById(id);

        if (studyGroupOpt.isPresent()) {
            StudyGroup studyGroup = studyGroupOpt.get();
            // Check if the current user is the owner
            if (studyGroup.getOwner().getId().equals(userId)) {
                studyGroupService.deleteStudyGroupById(id);
                redirectAttributes.addFlashAttribute("success", "Study group deleted successfully.");
                return "redirect:/studygroups/all";
            } else {
                redirectAttributes.addFlashAttribute("error", "You do not have permission to delete this study group.");
                return "redirect:/studygroups/view/" + id;
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Study group not found.");
            return "redirect:/studygroups/all";
        }
    }
    
    @PostMapping("join/{id}")
    public String joinStudyGroup1(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        Optional<Student> studentOpt = Optional.ofNullable(studentService.findStudentById(userId));
        Optional<StudyGroup> studyGroupOpt = studyGroupService.findStudyGroupById(id);

        if (studentOpt.isPresent() && studyGroupOpt.isPresent()) {
            StudyGroup studyGroup = studyGroupOpt.get();
            Student student = studentOpt.get();

            // Check if the user is already a member or the owner
            if (!studyGroup.getMembers().contains(student) && !studyGroup.getOwner().equals(student)) {
                studyGroup.getMembers().add(student);
                studyGroupService.saveStudyGroup(studyGroup);
                redirectAttributes.addFlashAttribute("success", "Successfully joined the study group.");
            } else {
                redirectAttributes.addFlashAttribute("info", "You are already a member or the owner of this group.");
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Study group or student not found.");
        }

        return "redirect:/studygroups/view/" + id;
    }
    @PostMapping("leave/{id}")
    public String leaveStudyGroup(@PathVariable Long id, HttpSession session, RedirectAttributes redirectAttributes) {
        Long userId = (Long) session.getAttribute("userId");
        Optional<StudyGroup> studyGroupOpt = studyGroupService.findStudyGroupById(id);

        if (studyGroupOpt.isPresent()) {
            StudyGroup studyGroup = studyGroupOpt.get();
            // Filter to remove the user from the group's members
            boolean removed = studyGroup.getMembers().removeIf(member -> member.getId().equals(userId));

            if (removed) {
                studyGroupService.saveStudyGroup(studyGroup);
                redirectAttributes.addFlashAttribute("success", "You have successfully left the group.");
            } else {
                redirectAttributes.addFlashAttribute("error", "You are not a member of this group.");
            }
        } else {
            redirectAttributes.addFlashAttribute("error", "Study group not found.");
        }

        return "redirect:/studygroups/view/" + id;
    }
}